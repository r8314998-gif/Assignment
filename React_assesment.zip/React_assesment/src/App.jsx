import React from "react";
import Calendar from "./componant/Calendar";
import "./App.css";

export default function App() {
  return (
    <div className="app ">
      <Calendar date={new Date(2025, 8, 18)} />
      <Calendar date={new Date(2025, 12, 30)} />
    </div>
  );
}
