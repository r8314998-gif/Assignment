import React from "react";


export default function Calendar({ date }) {
    const year = date.getFullYear();
    const month = date.getMonth();
    const today = date.getDate();

    const monthName = date.toLocaleString("default", { month: "long" });
    const weekDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const prevMonthDays = new Date(year, month, 0).getDate();

    const cells = [];

    // Previous month spillover
    for (let i = firstDay - 1; i >= 0; i--) {
        cells.push({ day: prevMonthDays - i, type: "prev" });
    }

    // Current month
    for (let i = 1; i <= daysInMonth; i++) {
        cells.push({ day: i, type: "current" });
    }

    // Next month spillover
    while (cells.length < 42) {
        cells.push({ day: cells.length - daysInMonth - firstDay + 1, type: "next" });
    }

    return (
        <div className="calendar">
            <div className="calendar-header">
                {monthName} {year}
            </div>

            <div className="weekdays">
                {weekDays.map(day => (
                    <div key={day}>{day}</div>
                ))}
            </div>

            <div className="calendar-grid">
                {cells.map((cell, index) => (
                    <div
                        key={index}
                        className={`cell ${cell.type} ${cell.type === "current" && cell.day === today ? "selected" : ""
                            }`}
                    >
                        {cell.day}
                    </div>
                ))}
            </div>
        </div>
    );
}
