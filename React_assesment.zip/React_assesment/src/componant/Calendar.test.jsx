import { render, screen } from "@testing-library/react";
import Calendar from "./Calendar";

test("renders correct month and year", () => {
  render(<Calendar date={new Date(2024, 0, 15)} />);
  expect(screen.getByText("January 2024")).toBeInTheDocument();
});

test("highlights selected date", () => {
  render(<Calendar date={new Date(2024, 0, 15)} />);
  const selectedDay = screen.getByText("15");
  expect(selectedDay).toHaveStyle("background-color: #1976d2");
});
