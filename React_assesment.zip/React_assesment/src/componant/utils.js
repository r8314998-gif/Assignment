export const WEEK_DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export const MONTH_NAMES = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
];

/**
 * Get the number of days in a month
 */
export const getDaysInMonth = (year, month) => {
    return new Date(year, month + 1, 0).getDate();
};

/**
 * Get the day of the week for the first day of the month (0 = Sunday, 6 = Saturday)
 */
export const getFirstDayOfMonth = (year, month) => {
    return new Date(year, month, 1).getDay();
};

/**
 * Generate calendar days array for the given month
 */
export const generateCalendarDays = (date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const currentDate = date.getDate();

    const daysInMonth = getDaysInMonth(year, month);
    const firstDayOfMonth = getFirstDayOfMonth(year, month);

    const days = [];

    // Add days from previous month
    const prevMonthDays = firstDayOfMonth;
    const prevMonthLastDate = new Date(year, month, 0).getDate();

    for (let i = prevMonthDays - 1; i >= 0; i--) {
        const dayDate = new Date(year, month - 1, prevMonthLastDate - i);
        days.push({
            date: dayDate.getDate(),
            isCurrentMonth: false,
            isHighlighted: false,
            fullDate: dayDate
        });
    }

    // Add days from current month
    for (let i = 1; i <= daysInMonth; i++) {
        const dayDate = new Date(year, month, i);
        const isHighlighted = i === currentDate;

        days.push({
            date: i,
            isCurrentMonth: true,
            isHighlighted,
            fullDate: dayDate
        });
    }

    // Add days from next month to complete the grid
    const totalCells = 42; // 6 weeks × 7 days
    const remainingCells = totalCells - days.length;

    for (let i = 1; i <= remainingCells; i++) {
        const dayDate = new Date(year, month + 1, i);
        days.push({
            date: i,
            isCurrentMonth: false,
            isHighlighted: false,
            fullDate: dayDate
        });
    }

    return days;
};

/**
 * Format month and year for display
 */
export const formatMonthYear = (date) => {
    const month = date.getMonth();
    const year = date.getFullYear();
    return `${MONTH_NAMES[month]} ${year}`;
};

/**
 * Check if two dates are the same day
 */
export const isSameDay = (date1, date2) => {
    return (
        date1.getFullYear() === date2.getFullYear() &&
        date1.getMonth() === date2.getMonth() &&
        date1.getDate() === date2.getDate()
    );
};